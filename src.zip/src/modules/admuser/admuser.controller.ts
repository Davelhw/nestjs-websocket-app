import { Controller } from '@nestjs/common';

@Controller('admuser')
export class AdmUserController {}
